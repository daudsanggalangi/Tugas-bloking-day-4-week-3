const API_BASE = "http://localhost:3000/api";

const DEFAULT_IMAGE =
    "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80";


const state = {

    search: "",

    category: "Semua",

    status: "semua",

    sortBy: "id",

    order: "DESC",

    page: 1,

    limit: 12,

    totalPages: 1,

    totalItems: 0,

    items: [],

    categories: [],

    stats: null,

    currentDetailItem: null,

    deleteTargetId: null

};


const $ = id =>
    document.getElementById(id);


const el = {

    serverStatus:
        $("serverStatus"),

    searchInput:
        $("searchInput"),

    btnClearSearch:
        $("btnClearSearch"),

    sortSelect:
        $("sortSelect"),

    statusFilter:
        $("statusFilter"),

    btnResetFilters:
        $("btnResetFilters"),

    categoriesContainer:
        $("categoriesContainer"),

    badgeAll:
        $("badgeAll"),

    menuGrid:
        $("menuGrid"),

    emptyState:
        $("emptyState"),

    btnEmptyReset:
        $("btnEmptyReset"),

    resultInfoText:
        $("resultInfoText"),

    resultText:
        $("resultText"),

    limitSelect:
        $("limitSelect"),

    paginationContainer:
        $("paginationContainer"),

    btnPrevPage:
        $("btnPrevPage"),

    btnNextPage:
        $("btnNextPage"),

    pageNumbers:
        $("pageNumbers"),

    statTotalMenu:
        $("statTotalMenu"),

    statTotalKategori:
        $("statTotalKategori"),

    statHargaMin:
        $("statHargaMin"),

    statTersedia:
        $("statTersedia"),

    btnOpenAddModal:
        $("btnOpenAddModal"),

    menuModal:
        $("menuModal"),

    modalTitle:
        $("modalTitle"),

    btnCloseModal:
        $("btnCloseModal"),

    btnCancelModal:
        $("btnCancelModal"),

    menuForm:
        $("menuForm"),

    menuId:
        $("menuId"),

    inputNama:
        $("inputNama"),

    inputKategori:
        $("inputKategori"),

    inputHarga:
        $("inputHarga"),

    inputStatus:
        $("inputStatus"),

    inputDeskripsi:
        $("inputDeskripsi"),

    inputGambar:
        $("inputGambar"),

    imagePreview:
        $("imagePreview"),

    btnSubmitMenu:
        $("btnSubmitMenu"),

    detailModal:
        $("detailModal"),

    btnCloseDetail:
        $("btnCloseDetail"),

    detailHeroImage:
        $("detailHeroImage"),

    detailCategory:
        $("detailCategory"),

    detailNama:
        $("detailNama"),

    detailHarga:
        $("detailHarga"),

    detailStatus:
        $("detailStatus"),

    detailDeskripsi:
        $("detailDeskripsi"),

    detailId:
        $("detailId"),

    detailCreatedAt:
        $("detailCreatedAt"),

    btnEditFromDetail:
        $("btnEditFromDetail"),

    btnDeleteFromDetail:
        $("btnDeleteFromDetail"),

    deleteModal:
        $("deleteModal"),

    deleteTargetName:
        $("deleteTargetName"),

    btnCancelDelete:
        $("btnCancelDelete"),

    btnConfirmDelete:
        $("btnConfirmDelete"),

    toastContainer:
        $("toastContainer")

};


/* =========================
   HELPER
========================= */

function rupiah(value) {

    return new Intl.NumberFormat(
        "id-ID",
        {
            style: "currency",
            currency: "IDR",
            maximumFractionDigits: 0
        }
    ).format(Number(value) || 0);

}


function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


function formatDate(value) {

    if (!value) {
        return "-";
    }

    const date =
        new Date(value);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return "-";
    }

    return date.toLocaleDateString(
        "id-ID",
        {
            day: "numeric",
            month: "long",
            year: "numeric"
        }
    );

}


function toast(
    message,
    type = "success"
) {

    const item =
        document.createElement("div");

    item.className =
        `toast ${type}`;

    item.textContent =
        message;

    el.toastContainer.appendChild(
        item
    );

    setTimeout(() => {

        item.style.opacity = "0";

        setTimeout(() => {

            item.remove();

        }, 300);

    }, 3000);

}


/* =========================
   CHECK API
========================= */

async function checkAPI() {

    try {

        const response =
            await fetch(
                `${API_BASE}/health`
            );

        if (!response.ok) {
            throw new Error();
        }

        el.serverStatus.className =
            "api-status online";

        el.serverStatus.querySelector(
            ".status-text"
        ).textContent =
            "API Terhubung";

    }

    catch {

        el.serverStatus.className =
            "api-status offline";

        el.serverStatus.querySelector(
            ".status-text"
        ).textContent =
            "API Terputus";

    }

}


/* =========================
   LOAD STATS
========================= */

async function loadStats() {

    try {

        const response =
            await fetch(
                `${API_BASE}/menu/stats`
            );

        const json =
            await response.json();

        if (!json.success) {
            return;
        }

        state.stats =
            json.data;

        el.statTotalMenu.textContent =
            json.data.totalMenu ?? 0;

        el.statTotalKategori.textContent =
            json.data.totalKategori ?? 0;

        el.statHargaMin.textContent =
            rupiah(
                json.data.hargaTerendah
            );

        el.statTersedia.textContent =
            json.data.totalTersedia ?? 0;

        el.badgeAll.textContent =
            json.data.totalMenu ?? 0;

    }

    catch (error) {

        console.error(
            "Stats:",
            error
        );

    }

}


/* =========================
   CATEGORIES
========================= */

async function loadCategories() {

    try {

        const response =
            await fetch(
                `${API_BASE}/menu/categories`
            );

        const json =
            await response.json();

        if (!json.success) {
            return;
        }

        state.categories =
            Array.isArray(json.data)
                ? json.data
                : [];

        renderCategories();

    }

    catch (error) {

        console.error(
            "Categories:",
            error
        );

    }

}


function renderCategories() {

    let html = `
        <button
            class="category ${
                state.category === "Semua"
                    ? "active"
                    : ""
            }"
            data-category="Semua"
        >
            Semua Menu
            <span>
                ${state.stats?.totalMenu ?? 0}
            </span>
        </button>
    `;


    state.categories.forEach(
        category => {

            const name =
                category.kategori;

            html += `
                <button
                    class="category ${
                        state.category === name
                            ? "active"
                            : ""
                    }"
                    data-category="${escapeHTML(name)}"
                >
                    ${escapeHTML(name)}

                    <span>
                        ${category.count ?? 0}
                    </span>

                </button>
            `;

        }
    );


    el.categoriesContainer.innerHTML =
        html;


    el.categoriesContainer
        .querySelectorAll(".category")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    state.category =
                        button.dataset.category;

                    state.page = 1;

                    renderCategories();

                    loadMenu();

                }
            );

        });

}


/* =========================
   LOAD MENU
========================= */

async function loadMenu() {

    showSkeleton();

    try {

        const params =
            new URLSearchParams();

        params.set(
            "page",
            state.page
        );

        params.set(
            "limit",
            state.limit
        );

        params.set(
            "sortBy",
            state.sortBy
        );

        params.set(
            "order",
            state.order
        );


        if (
            state.search.trim()
        ) {

            params.set(
                "search",
                state.search.trim()
            );

        }


        if (
            state.category !== "Semua"
        ) {

            params.set(
                "kategori",
                state.category
            );

        }


        if (
            state.status !== "semua"
        ) {

            params.set(
                "status",
                state.status
            );

        }


        const response =
            await fetch(
                `${API_BASE}/menu?${params}`
            );


        if (!response.ok) {

            throw new Error(
                "Gagal mengambil data menu"
            );

        }


        const json =
            await response.json();


        state.items =
            json.data || [];


        if (json.pagination) {

            state.totalItems =
                json.pagination.totalItems ??
                0;

            state.totalPages =
                json.pagination.totalPages ??
                1;

            state.page =
                json.pagination.currentPage ??
                state.page;

        }


        renderMenu();

        renderPagination();

        updateResult();

    }

    catch (error) {

        console.error(error);

        el.menuGrid.innerHTML = `

            <div
                style="
                    grid-column:1/-1;
                    text-align:center;
                    padding:70px 20px;
                "
            >

                <div
                    style="
                        font-size:45px;
                    "
                >
                    ⚠️
                </div>

                <h3
                    style="
                        margin:15px 0;
                    "
                >
                    Gagal Memuat Menu
                </h3>

                <p
                    style="
                        color:#8993a6;
                    "
                >
                    Pastikan backend berjalan
                    di port 3000.
                </p>

                <br>

                <button
                    class="btn-primary"
                    onclick="loadMenu()"
                >
                    Coba Lagi
                </button>

            </div>

        `;

        el.paginationContainer
            .classList.add("hidden");

    }

}


/* =========================
   SKELETON
========================= */

function showSkeleton() {

    const count =
        state.limit === 0
            ? 8
            : Math.min(
                state.limit,
                8
            );

    let html = "";

    for (
        let i = 0;
        i < count;
        i++
    ) {

        html += `
            <div class="skeleton"></div>
        `;

    }

    el.menuGrid.innerHTML =
        html;

    el.emptyState.classList.add(
        "hidden"
    );

}


/* =========================
   RENDER MENU
========================= */

function renderMenu() {

    if (
        !state.items.length
    ) {

        el.menuGrid.innerHTML =
            "";

        el.emptyState.classList.remove(
            "hidden"
        );

        el.paginationContainer
            .classList.add("hidden");

        return;

    }


    el.emptyState.classList.add(
        "hidden"
    );


    let html = "";


    state.items.forEach(
        item => {

            const available =
                item.status === "tersedia";


            const image =
                item.gambar ||
                DEFAULT_IMAGE;


            html += `

                <article
                    class="menu-card"
                    data-id="${item.id}"
                >

                    <div class="card-image">

                        <img
                            src="${escapeHTML(image)}"
                            alt="${escapeHTML(item.nama)}"
                            loading="lazy"
                            onerror="
                                this.onerror=null;
                                this.src='${DEFAULT_IMAGE}'
                            "
                        >

                        <span class="card-category">
                            ${escapeHTML(
                                item.kategori
                            )}
                        </span>

                        <span
                            class="
                                card-status
                                ${
                                    available
                                        ? "available"
                                        : "sold-out"
                                }
                            "
                        >
                            ${
                                available
                                    ? "Tersedia"
                                    : "Habis"
                            }
                        </span>

                    </div>


                    <div class="card-content">

                        <h3
                            class="card-title"
                            data-action="detail"
                        >
                            ${escapeHTML(
                                item.nama
                            )}
                        </h3>


                        <p class="card-description">

                            ${escapeHTML(
                                item.deskripsi ||
                                "Hidangan khas Cita Rasa Pertiwi dengan cita rasa autentik."
                            )}

                        </p>


                        <div class="card-bottom">

                            <strong class="card-price">

                                ${rupiah(
                                    item.harga
                                )}

                            </strong>


                            <div class="card-actions">

                                <button
                                    class="card-action"
                                    title="Lihat Detail"
                                    data-action="detail"
                                >
                                    👁
                                </button>

                                <button
                                    class="card-action"
                                    title="Edit"
                                    data-action="edit"
                                >
                                    ✎
                                </button>

                                <button
                                    class="
                                        card-action
                                        delete
                                    "
                                    title="Hapus"
                                    data-action="delete"
                                >
                                    ×
                                </button>

                            </div>

                        </div>

                    </div>

                </article>

            `;

        }
    );


    el.menuGrid.innerHTML =
        html;


    el.menuGrid
        .querySelectorAll(".menu-card")
        .forEach(card => {

            const id =
                card.dataset.id;


            const item =
                state.items.find(
                    menu =>
                        String(menu.id) ===
                        String(id)
                );


            card.querySelectorAll(
                "[data-action]"
            )
            .forEach(button => {

                button.addEventListener(
                    "click",
                    event => {

                        event.stopPropagation();

                        const action =
                            button.dataset.action;


                        if (
                            action ===
                            "detail"
                        ) {

                            openDetail(
                                item
                            );

                        }


                        if (
                            action ===
                            "edit"
                        ) {

                            openEdit(
                                item
                            );

                        }


                        if (
                            action ===
                            "delete"
                        ) {

                            openDelete(
                                item
                            );

                        }

                    }
                );

            });

        });

}


/* =========================
   RESULT
========================= */

function updateResult() {

    if (
        !state.totalItems
    ) {

        el.resultInfoText.textContent =
            "Tidak ada menu";

        el.resultText.textContent =
            "Tidak ada menu yang ditemukan";

        return;

    }


    const start =
        state.limit === 0
            ? 1
            : (
                state.page - 1
            ) *
                state.limit +
                1;


    const end =
        state.limit === 0
            ? state.totalItems
            : Math.min(
                state.page *
                    state.limit,
                state.totalItems
            );


    const text =
        `Menampilkan ${start}–${end} dari ${state.totalItems} menu`;


    el.resultInfoText.textContent =
        text;

    el.resultText.textContent =
        text;

}


/* =========================
   PAGINATION
========================= */

function renderPagination() {

    if (
        state.totalPages <= 1
    ) {

        el.paginationContainer
            .classList.add("hidden");

        return;

    }


    el.paginationContainer
        .classList.remove("hidden");


    el.btnPrevPage.disabled =
        state.page <= 1;


    el.btnNextPage.disabled =
        state.page >=
        state.totalPages;


    let pages = [];


    for (
        let i = 1;
        i <= state.totalPages;
        i++
    ) {

        if (
            i === 1 ||
            i === state.totalPages ||
            Math.abs(
                i - state.page
            ) <= 1
        ) {

            pages.push(i);

        }

    }


    pages =
        [
            ...new Set(pages)
        ]
        .sort(
            (a,b) => a - b
        );


    let html = "";

    let previous = null;


    pages.forEach(
        page => {

            if (
                previous !== null &&
                page - previous > 1
            ) {

                html += `
                    <span>...</span>
                `;

            }


            html += `

                <button
                    class="
                        page-number
                        ${
                            page === state.page
                                ? "active"
                                : ""
                        }
                    "
                    data-page="${page}"
                >
                    ${page}
                </button>

            `;


            previous = page;

        }
    );


    el.pageNumbers.innerHTML =
        html;


    el.pageNumbers
        .querySelectorAll(
            ".page-number"
        )
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    state.page =
                        Number(
                            button.dataset.page
                        );

                    loadMenu();

                    window.scrollTo(
                        {
                            top: 500,
                            behavior: "smooth"
                        }
                    );

                }
            );

        });

}


/* =========================
   ADD
========================= */

function openAdd() {

    el.modalTitle.textContent =
        "Tambah Menu Baru";

    el.menuForm.reset();

    el.menuId.value =
        "";

    el.inputStatus.value =
        "tersedia";

    el.imagePreview.src =
        "";

    el.imagePreview.classList.add(
        "hidden"
    );

    el.menuModal.classList.remove(
        "hidden"
    );

    el.inputNama.focus();

}


/* =========================
   EDIT
========================= */

function openEdit(item) {

    if (!item) {
        return;
    }


    el.modalTitle.textContent =
        "Edit Hidangan";


    el.menuId.value =
        item.id;


    el.inputNama.value =
        item.nama;


    el.inputKategori.value =
        item.kategori;


    el.inputHarga.value =
        item.harga;


    el.inputStatus.value =
        item.status ||
        "tersedia";


    el.inputDeskripsi.value =
        item.deskripsi ||
        "";


    el.inputGambar.value =
        item.gambar ||
        "";


    if (item.gambar) {

        el.imagePreview.src =
            item.gambar;

        el.imagePreview.classList.remove(
            "hidden"
        );

    }

    else {

        el.imagePreview.classList.add(
            "hidden"
        );

    }


    el.menuModal.classList.remove(
        "hidden"
    );

}


function closeMenuModal() {

    el.menuModal.classList.add(
        "hidden"
    );

}


/* =========================
   DETAIL
========================= */

function openDetail(item) {

    if (!item) {
        return;
    }


    state.currentDetailItem =
        item;


    const image =
        item.gambar ||
        DEFAULT_IMAGE;


    el.detailHeroImage.style.backgroundImage =
        `url("${image}")`;


    el.detailCategory.textContent =
        item.kategori;


    el.detailNama.textContent =
        item.nama;


    el.detailHarga.textContent =
        rupiah(
            item.harga
        );


    const available =
        item.status === "tersedia";


    el.detailStatus.textContent =
        available
            ? "Tersedia"
            : "Habis";


    el.detailStatus.className =
        `status-badge ${
            available
                ? "status-tersedia"
                : "status-habis"
        }`;


    el.detailDeskripsi.textContent =
        item.deskripsi ||
        "Tidak ada deskripsi.";


    el.detailId.textContent =
        `#${item.id}`;


    el.detailCreatedAt.textContent =
        formatDate(
            item.created_at
        );


    el.detailModal.classList.remove(
        "hidden"
    );

}


function closeDetail() {

    el.detailModal.classList.add(
        "hidden"
    );

    state.currentDetailItem =
        null;

}


/* =========================
   DELETE MODAL
========================= */

function openDelete(item) {

    if (!item) {
        return;
    }


    state.deleteTargetId =
        item.id;


    el.deleteTargetName.textContent =
        item.nama;


    el.deleteModal.classList.remove(
        "hidden"
    );

}


function closeDelete() {

    el.deleteModal.classList.add(
        "hidden"
    );

    state.deleteTargetId =
        null;

}


/* =========================
   SAVE MENU
========================= */

async function saveMenu(event) {

    event.preventDefault();


    const id =
        el.menuId.value;


    const editing =
        Boolean(id);


    const payload = {

        nama:
            el.inputNama.value.trim(),

        kategori:
            el.inputKategori.value.trim(),

        harga:
            Number(
                el.inputHarga.value
            ),

        status:
            el.inputStatus.value,

        deskripsi:
            el.inputDeskripsi.value.trim(),

        gambar:
            el.inputGambar.value.trim() ||
            null

    };


    if (
        !payload.nama ||
        !payload.kategori ||
        !payload.harga ||
        payload.harga <= 0
    ) {

        toast(
            "Lengkapi data menu terlebih dahulu.",
            "error"
        );

        return;

    }


    el.btnSubmitMenu.disabled =
        true;


    el.btnSubmitMenu.querySelector(
        ".btn-text"
    ).textContent =
        "Menyimpan...";


    try {

        const url =
            editing
                ? `${API_BASE}/menu/${id}`
                : `${API_BASE}/menu`;


        const method =
            editing
                ? "PUT"
                : "POST";


        const response =
            await fetch(
                url,
                {

                    method,

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            payload
                        )

                }
            );


        const json =
            await response.json();


        if (
            !response.ok ||
            !json.success
        ) {

            throw new Error(
                json.message ||
                "Gagal menyimpan menu"
            );

        }


        toast(
            editing
                ? "Menu berhasil diperbarui."
                : "Menu berhasil ditambahkan."
        );


        closeMenuModal();


        await Promise.all(
            [
                loadStats(),
                loadCategories()
            ]
        );


        await loadMenu();

    }

    catch (error) {

        console.error(error);

        toast(
            error.message ||
            "Terjadi kesalahan.",
            "error"
        );

    }

    finally {

        el.btnSubmitMenu.disabled =
            false;

        el.btnSubmitMenu.querySelector(
            ".btn-text"
        ).textContent =
            "Simpan Menu";

    }

}


/* =========================
   DELETE MENU
========================= */

async function deleteMenu() {

    if (
        !state.deleteTargetId
    ) {

        return;

    }


    el.btnConfirmDelete.disabled =
        true;


    el.btnConfirmDelete.textContent =
        "Menghapus...";


    try {

        const response =
            await fetch(
                `${API_BASE}/menu/${state.deleteTargetId}`,
                {
                    method: "DELETE"
                }
            );


        const json =
            await response.json();


        if (
            !response.ok ||
            !json.success
        ) {

            throw new Error(
                json.message ||
                "Gagal menghapus menu"
            );

        }


        toast(
            "Menu berhasil dihapus."
        );


        closeDelete();

        closeDetail();


        await Promise.all(
            [
                loadStats(),
                loadCategories()
            ]
        );


        await loadMenu();

    }

    catch (error) {

        console.error(error);

        toast(
            error.message ||
            "Gagal menghapus menu.",
            "error"
        );

    }

    finally {

        el.btnConfirmDelete.disabled =
            false;

        el.btnConfirmDelete.textContent =
            "Ya, Hapus";

    }

}


/* =========================
   SEARCH
========================= */

let searchTimer;


el.searchInput.addEventListener(
    "input",
    event => {

        const value =
            event.target.value;


        el.btnClearSearch.style.display =
            value
                ? "block"
                : "none";


        clearTimeout(
            searchTimer
        );


        searchTimer =
            setTimeout(
                () => {

                    state.search =
                        value;

                    state.page =
                        1;

                    loadMenu();

                },
                300
            );

    }
);


el.btnClearSearch.addEventListener(
    "click",
    () => {

        el.searchInput.value =
            "";

        el.btnClearSearch.style.display =
            "none";

        state.search =
            "";

        state.page =
            1;

        loadMenu();

    }
);


/* =========================
   SORT
========================= */

el.sortSelect.addEventListener(
    "change",
    event => {

        const [
            sort,
            order
        ] =
            event.target.value
                .split("-");


        state.sortBy =
            sort;


        state.order =
            order.toUpperCase();


        state.page =
            1;


        loadMenu();

    }
);


/* =========================
   STATUS
========================= */

el.statusFilter.addEventListener(
    "change",
    event => {

        state.status =
            event.target.value;

        state.page =
            1;

        loadMenu();

    }
);


/* =========================
   LIMIT
========================= */

el.limitSelect.addEventListener(
    "change",
    event => {

        state.limit =
            Number(
                event.target.value
            );

        state.page =
            1;

        loadMenu();

    }
);


/* =========================
   RESET
========================= */

function resetFilters() {

    state.search =
        "";

    state.category =
        "Semua";

    state.status =
        "semua";

    state.sortBy =
        "id";

    state.order =
        "DESC";

    state.page =
        1;


    el.searchInput.value =
        "";


    el.sortSelect.value =
        "id-desc";


    el.statusFilter.value =
        "semua";


    el.btnClearSearch.style.display =
        "none";


    renderCategories();

    loadMenu();

}


el.btnResetFilters.addEventListener(
    "click",
    resetFilters
);


el.btnEmptyReset.addEventListener(
    "click",
    resetFilters
);


/* =========================
   PAGINATION BUTTON
========================= */

el.btnPrevPage.addEventListener(
    "click",
    () => {

        if (
            state.page <= 1
        ) {
            return;
        }


        state.page--;


        loadMenu();


        window.scrollTo(
            {
                top: 500,
                behavior: "smooth"
            }
        );

    }
);


el.btnNextPage.addEventListener(
    "click",
    () => {

        if (
            state.page >=
            state.totalPages
        ) {
            return;
        }


        state.page++;


        loadMenu();


        window.scrollTo(
            {
                top: 500,
                behavior: "smooth"
            }
        );

    }
);


/* =========================
   IMAGE PREVIEW
========================= */

el.inputGambar.addEventListener(
    "input",
    event => {

        const url =
            event.target.value.trim();


        if (!url) {

            el.imagePreview.src =
                "";

            el.imagePreview.classList.add(
                "hidden"
            );

            return;

        }


        el.imagePreview.src =
            url;


        el.imagePreview.classList.remove(
            "hidden"
        );


        el.imagePreview.onerror =
            () => {

                el.imagePreview.src =
                    DEFAULT_IMAGE;

            };

    }
);


/* =========================
   MODAL EVENTS
========================= */

el.btnOpenAddModal.addEventListener(
    "click",
    openAdd
);


el.btnCloseModal.addEventListener(
    "click",
    closeMenuModal
);


el.btnCancelModal.addEventListener(
    "click",
    closeMenuModal
);


el.menuForm.addEventListener(
    "submit",
    saveMenu
);


el.btnCloseDetail.addEventListener(
    "click",
    closeDetail
);


el.btnEditFromDetail.addEventListener(
    "click",
    () => {

        const item =
            state.currentDetailItem;

        closeDetail();

        openEdit(item);

    }
);


el.btnDeleteFromDetail.addEventListener(
    "click",
    () => {

        openDelete(
            state.currentDetailItem
        );

    }
);


el.btnCancelDelete.addEventListener(
    "click",
    closeDelete
);


el.btnConfirmDelete.addEventListener(
    "click",
    deleteMenu
);


[
    el.menuModal,
    el.detailModal,
    el.deleteModal
]
.forEach(
    modal => {

        modal.addEventListener(
            "click",
            event => {

                if (
                    event.target === modal
                ) {

                    modal.classList.add(
                        "hidden"
                    );

                }

            }
        );

    }
);


document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape"
        ) {

            closeMenuModal();

            closeDetail();

            closeDelete();

        }

    }
);


/* =========================
   INITIALIZATION
========================= */

async function init() {

    await checkAPI();

    await Promise.all(
        [
            loadStats(),
            loadCategories()
        ]
    );

    await loadMenu();


    setInterval(
        checkAPI,
        30000
    );

}


document.addEventListener(
    "DOMContentLoaded",
    init
);